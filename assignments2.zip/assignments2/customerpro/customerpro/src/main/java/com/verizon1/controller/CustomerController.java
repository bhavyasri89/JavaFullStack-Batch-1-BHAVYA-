package com.verizon1.controller;

import java.sql.Date;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.verizon.model.Customer;
import com.verizon.service.CustomerService;

@RestController
public class CustomerController {
    @Autowired
    CustomerService customerService;

    @GetMapping("/customer")
    public List<Customer> getCustomerDetails() {
        return customerService.getCustomers();
    }

    @GetMapping("/customer/{cid}")
    public Customer getCustomerDetails(@PathVariable("cid") Integer cid) {
        return customerService.getCustomers(cid);
    }

    @GetMapping("/customerByDateRange")
    public List<Customer> getCustomersByDateRange(
            @RequestParam("startDate") @DateTimeFormat(pattern = "yyyy-MM-dd") Date startDate,
            @RequestParam("endDate") @DateTimeFormat(pattern = "yyyy-MM-dd") Date endDate) {
        return customerService.getCustomersByDateRange(startDate, endDate);
    }
}
