package com.verizon1.dao;

import java.sql.Date;
import java.util.List;

import com.verizon1.model.Customer;

@Repository
public interface CustomerDao extends JpaRepository<Customer, Integer> {

	List<Customer> findByRegisterDateBetween(Date startDate, Date endDate);
}