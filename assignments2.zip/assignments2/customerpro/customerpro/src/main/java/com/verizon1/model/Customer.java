package com.verizon1.model;

import java.sql.Date;




@Entity
//@Table(name="CustomerTable")
public class Customer {
	@Id
	Integer cid;
	@Column
	String cname;
	String phn;
	String email;
	String location;
	Date registerDate;
	Customer(){
		
	}
	public Customer(Integer cid, String cname, String phn, String email, String location, Date registerDate) {
		super();
		this.cid = cid;
		this.cname = cname;
		this.phn = phn;
		this.email = email;
		this.location = location;
		this.registerDate = registerDate;
	}
	
	 
	@Override
	public String toString() {
		return "Customer [cid=" + cid + ", cname=" + cname + ", phn=" + phn + ", email=" + email + ", location="
				+ location + ", registerDate=" + registerDate + "]";
	}
	public Integer getCid() {
		return cid;
	}
	public void setCid(Integer cid) {
		this.cid = cid;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public String getPhn() {
		return phn;
	}
	public void setPhn(String phn) {
		this.phn = phn;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public Date getRegisterDate() {
		return registerDate;
	}
	public void setRegisterDate(Date registerDate) {
		this.registerDate = registerDate;
	}
	

}
