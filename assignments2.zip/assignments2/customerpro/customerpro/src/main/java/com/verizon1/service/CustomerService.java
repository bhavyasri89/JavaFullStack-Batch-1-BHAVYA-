package com.verizon1.service;

import java.util.List;

import com.verizon1.dao.CustomerDao;
import com.verizon1.model.Customer;

@Service
@Transactional
public class CustomerService {
    @Autowired
    CustomerDao customerDao;

    public Customer getCustomers(Integer cid) {
        return customerDao.findById(cid).orElse(null);
    }

    public List<Customer> getCustomers() {
        return customerDao.findAll();
    }

    public List<Customer> getCustomersByDateRange(Date startDate, Date endDate) {
        return customerDao.findCustomersByDateRange(startDate, endDate);
    }
}
