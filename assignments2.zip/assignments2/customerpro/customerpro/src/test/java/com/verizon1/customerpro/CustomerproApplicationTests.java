package com.verizon1.customerpro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomerproApplicationTests {

	@Test
	void contextLoads() {
	}

}
