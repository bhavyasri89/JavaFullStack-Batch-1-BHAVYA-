package com.verizon.producerapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

@SpringBootApplication
@EnableDiscoveryClient
public class ProducerappApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProducerappApplication.class, args);
	}

}
