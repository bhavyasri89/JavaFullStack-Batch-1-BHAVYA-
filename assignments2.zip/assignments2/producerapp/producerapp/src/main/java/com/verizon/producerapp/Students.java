package com.verizon.producerapp;

import java.io.Serializable;

public class Students {
	@Entity
	@Table(name="students")
	public class Student implements Serializable{
		private static final long serialVersionUID=1L;
		@ID
		private int studentId;
		private String name;
		
		@oneToOne(cascade=CascadeType.ALL)
		@JoinColumn(name="address_id")
		private Address address;
		
		
		public Address getAddress() {
			return address;
		}
		public void setAddress(Address address) {
			this.address = address;
		}
		public int getStudentId() {
			return studentId;
		
		}
		public void setStudentId(int studentId) {
			this.studentId = studentId;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}

		
	}

}
