package com.verizon.seleniumapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SeleniumappApplication {

	public static void main(String[] args) {
		SpringApplication.run(SeleniumappApplication.class, args);
	}

}
