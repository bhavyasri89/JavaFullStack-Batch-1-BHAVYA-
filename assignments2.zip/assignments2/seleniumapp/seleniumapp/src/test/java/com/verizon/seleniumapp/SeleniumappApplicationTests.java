package com.verizon.seleniumapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SeleniumappApplicationTests {

	@Test
	void contextLoads() {
	}

}
