class Customername{
String name;
Customername(String name){
this.name=name;
}
void displayMessage(){
System.out.println(this.name);
}
public static void main(String[] args){
Customername e=new Customername("Hello this is raju");
e.displayMessage();
}
}